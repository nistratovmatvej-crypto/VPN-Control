# VPN Control 0.4.1

Android VPN manager based on the AmneziaWG Android tunnel library.

## Included
- AmneziaWG tunnel backend (`com.zaneschepke:amneziawg-android:2.3.7`), including AWG obfuscation fields supported by the library.
- Encrypted local profile storage using Android Keystore AES-GCM.
- Multiple profiles, active profile selection and favorites.
- Password-encrypted portable backup/restore (PBKDF2-HMAC-SHA256 + AES-256-GCM).
- Android system Kill Switch setup path: the app advertises Always-on VPN support and opens Android VPN settings. The user must enable Always-on and “Block connections without VPN” manually; ordinary apps cannot grant themselves device-owner lockdown privileges. Lockdown can block apps excluded by split tunneling.
- Daily/monthly VPN-only totals from native AmneziaWG peer counters, sampled by a foreground service every 10 seconds while the tunnel is active.
- Server auto-selection tests saved profiles by establishing the AWG tunnel and waiting for a recent peer handshake.

## Build
Requires JDK 17, Android SDK platform 36 and Gradle 8.13.

```bash
gradle --no-daemon assembleDebug
```

GitHub Actions builds `app-debug.apk` as the `VPN-Control-debug` artifact.

## Important limitations
- Android does not let an ordinary app silently enable the system lockdown toggle. The user must enable Always-on VPN and “Block connections without VPN” in Android Settings.
- Handshake establishment time is a useful availability/connection-time signal, not a direct throughput benchmark.
- Daily/monthly totals are local estimates accumulated from 10-second samples; a force-stop, crash, or reboot can lose the final unsampled interval.
- Private DNS settings remain controlled by Android. VPN Control can open the relevant system page but cannot silently change Private DNS.
- This archive has not been built on a physical Android device in this environment. CI build is required before installation.

## 0.4.1 — tunnel statistics and handshake-based selection

- Daily/monthly counters accumulate native AmneziaWG peer byte statistics, not device-wide TrafficStats totals.
- A foreground sampler polls tunnel counters every 10 seconds while VPN is active.
- Automatic selection establishes each saved profile, waits for a recent peer handshake, ranks successful handshakes, then reconnects and verifies the winner.
- Kill Switch status is shown where Android exposes it. Enabling system lockdown remains a user action in Android VPN settings.
