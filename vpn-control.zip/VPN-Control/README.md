# VPN Control 0.2.0

Android app built with Kotlin + Gradle. No Python is used.

## What's implemented
- Foreground app detection using Android UsageStats events (requires the user to grant Usage Access).
- Rule engine: Telegram / YouTube -> start WireGuard; Claude -> stop WireGuard and show a Private DNS reminder; other foreground apps -> stop WireGuard.
- Embedded official WireGuard tunnel library (`com.wireguard.android:tunnel`).
- Import of a WireGuard `.conf` profile through Android's document picker.
- Explicit Android VPN consent flow and foreground notifications.
- Dark control-panel UI with live permission and DNS status.

## Important Android limitations
- A working VPN requires a valid WireGuard `.conf` from a VPN provider or a server the user controls. This project does not include a VPN server, credentials, or a bundled commercial VPN subscription.
- Android allows only one active VPN service per user/profile. The current rule engine turns the whole WireGuard tunnel on/off; it does not yet isolate only Telegram/YouTube traffic.
- Regular third-party apps cannot silently change the system Private DNS setting. The app can read its current status and open Android's settings, but the user must change it there. DNS configured inside a WireGuard profile is separate from Android Private DNS.
- Usage access is approximate foreground-app monitoring, not an instant OS callback. Android battery/background restrictions may delay it; keep the monitoring notification enabled and exempt the app from aggressive battery optimization if the tablet manufacturer requires it.
- On first use, open VPN Control, import the `.conf`, grant Usage Access, then press **Connect VPN** once and approve Android's VPN dialog. After that, start automation.

## Build on GitHub Actions
Upload the contents of this project folder to the repository root, then run the `Build VPN Control APK` workflow. Download the `VPN-Control-debug` artifact.

Never commit a WireGuard `.conf`, private keys, or credentials to GitHub. Import the config directly on the tablet instead.
