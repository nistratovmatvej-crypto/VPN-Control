# VPN Control 0.1.0

Android starter project (Kotlin + Gradle). Built in GitHub Actions; no Python or local Android Studio required.

## Cloud build
1. Create a GitHub repository named `VPN-Control`.
2. Upload the contents of this folder to the repository root (not the containing folder).
3. Open **Actions** → **Build VPN Control APK** → **Run workflow**.
4. When the run completes, download the `VPN-Control-debug` artifact.

## Current status
This is a buildable starter UI, not yet a functioning VPN/DNS automation app. It currently provides the control-panel shell and a link to Android's Usage Access and Private DNS settings. Next work: app-usage monitoring, safe Private DNS state management, foreground service, and AmneziaWG engine integration.

Never commit VPN `.conf` files, private keys, or screenshots containing secrets to this repository.
