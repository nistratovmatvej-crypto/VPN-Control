package com.vpncontrol.app

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

class AppMonitorService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastPackage = ""
    private var lastDnsNotice = 0L
    private val tick = object : Runnable {
        override fun run() {
            val pkg = foregroundPackage()
            if (pkg.isNotBlank() && pkg != lastPackage) {
                lastPackage = pkg
                getSharedPreferences("vpncontrol", MODE_PRIVATE).edit().putString("foregroundPackage", pkg).apply()
                when (pkg) {
                    "org.telegram.messenger", "com.google.android.youtube" -> setVpn(true)
                    "com.anthropic.claude" -> {
                        setVpn(false)
                        val now = System.currentTimeMillis()
                        if (now - lastDnsNotice > 60_000) {
                            lastDnsNotice = now
                            notifyUser("Claude открыт", "Private DNS нельзя переключить автоматически. Проверь системные настройки DNS.")
                        }
                    }
                    else -> setVpn(false)
                }
            }
            handler.postDelayed(this, 2000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(3101, notification("Автоматизация активна", "Отслеживаем активное приложение"))
        handler.post(tick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun foregroundPackage(): String {
        val manager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val events = manager.queryEvents(end - 10_000, end)
        val event = UsageEvents.Event()
        var latestTime = 0L
        var latest = ""
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            val foreground = if (Build.VERSION.SDK_INT >= 29) event.eventType == UsageEvents.Event.ACTIVITY_RESUMED
                else event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
            if (foreground && event.timeStamp >= latestTime) { latestTime = event.timeStamp; latest = event.packageName }
        }
        return latest
    }

    private fun setVpn(enabled: Boolean) {
        val prefs = getSharedPreferences("vpncontrol", MODE_PRIVATE)
        if (enabled && !java.io.File(filesDir, "active.conf").exists()) {
            notifyUser("VPN не настроен", "Импортируй WireGuard .conf в VPN Control")
            return
        }
        val action = if (enabled) WireGuardControllerService.ACTION_UP else WireGuardControllerService.ACTION_DOWN
        val i = Intent(this, WireGuardControllerService::class.java).setAction(action)
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        } catch (_: Exception) { notifyUser("Не удалось применить правило", "Открой VPN Control и проверь разрешения") }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("vpncontrol", "VPN Control", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    @Suppress("DEPRECATION")
    private fun notification(title: String, body: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "vpncontrol") else Notification.Builder(this)
        return builder.setContentTitle(title).setContentText(body).setSmallIcon(android.R.drawable.stat_sys_warning).build()
    }

    private fun notifyUser(title: String, body: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify((title + body).hashCode(), notification(title, body))
    }

    override fun onDestroy() { handler.removeCallbacks(tick); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
