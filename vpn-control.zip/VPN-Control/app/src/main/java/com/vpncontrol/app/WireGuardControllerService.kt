package com.vpncontrol.app

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.File
import java.io.FileInputStream

class WireGuardControllerService : Service() {
    companion object {
        const val ACTION_UP = "com.vpncontrol.app.WG_UP"
        const val ACTION_DOWN = "com.vpncontrol.app.WG_DOWN"
    }
    private val tunnel = object : Tunnel {
        override fun getName(): String = "VPNControl"
        override fun onStateChange(newState: Tunnel.State) { }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        startForeground(3102, notification("VPN Control", "Применяем VPN-правило…"))
        Thread {
            try {
                val backend = GoBackend(applicationContext)
                if (intent?.action == ACTION_UP) {
                    val file = File(filesDir, "active.conf")
                    if (!file.exists()) throw IllegalStateException("WireGuard profile missing")
                    val config = FileInputStream(file).use { Config.parse(it) }
                    backend.setState(tunnel, Tunnel.State.UP, config)
                    getSharedPreferences("vpncontrol", MODE_PRIVATE).edit().putBoolean("vpnWasStarted", true).apply()
                    notifyResult("VPN подключён", "WireGuard-туннель активен")
                } else {
                    backend.setState(tunnel, Tunnel.State.DOWN, null)
                    getSharedPreferences("vpncontrol", MODE_PRIVATE).edit().putBoolean("vpnWasStarted", false).apply()
                    notifyResult("VPN отключён", "Правило применено")
                }
            } catch (e: Exception) {
                notifyResult("Ошибка VPN", e.message ?: "Не удалось применить конфигурацию")
            } finally { stopSelf(startId) }
        }.start()
        return START_NOT_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("vpncontrol", "VPN Control", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    @Suppress("DEPRECATION")
    private fun notification(title: String, body: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "vpncontrol") else Notification.Builder(this)
        return builder.setContentTitle(title).setContentText(body).setSmallIcon(android.R.drawable.stat_sys_warning).build()
    }
    private fun notifyResult(title: String, body: String) {
        val n = notification(title, body)
        getSystemService(NotificationManager::class.java).notify(title.hashCode(), n)
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
