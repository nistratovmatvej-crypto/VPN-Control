package com.vpncontrol.app

import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = 0xFF090D18.toInt()
    private val panel = 0xFF151D2E.toInt()
    private val muted = 0xFFAAB5CC.toInt()
    private val accent = 0xFF9BAAFF.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 8, 0, 8)
        }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundColor(0xFF34466F.toInt())
        setOnClickListener { action() }
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 26, 22, 24)
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { addView(root) }
        root.addView(text("VPN CONTROL", 27f, 0xFFFFFFFF.toInt(), true))
        root.addView(text("AUTOMATION CENTER  ·  VERSION 0.1.0", 11f, muted, true))
        root.addView(text("Панель управления", 18f, 0xFFFFFFFF.toInt(), true).apply { setPadding(0, 30, 0, 12) })

        val status = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            setBackgroundColor(panel)
        }
        status.addView(text("●  СИСТЕМА НЕ НАСТРОЕНА", 14f, 0xFFFFC66D.toInt(), true))
        status.addView(text("Это стартовая сборка. VPN и DNS пока не переключаются — сначала нужно выдать разрешения и подключить безопасный VPN-модуль.", 14f, muted))
        root.addView(status)

        root.addView(text("АВТОМАТИЧЕСКИЕ ПРАВИЛА", 12f, accent, true).apply { setPadding(0, 26, 0, 8) })
        listOf(
            "Telegram  →  VPN ВКЛ · Private DNS ВЫКЛ",
            "YouTube  →  VPN ВКЛ · Private DNS ВЫКЛ",
            "Claude  →  Private DNS ВКЛ независимо от VPN",
            "Нет целевых приложений  →  VPN ВЫКЛ · DNS ВКЛ"
        ).forEach { rule ->
            val card = TextView(this).apply {
                text = rule
                textSize = 14f
                setTextColor(0xFFE6EBF5.toInt())
                setPadding(15, 15, 15, 15)
                setBackgroundColor(panel)
            }
            val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 }
            root.addView(card, params)
        }

        root.addView(text("ПЕРВОНАЧАЛЬНАЯ НАСТРОЙКА", 12f, accent, true).apply { setPadding(0, 22, 0, 8) })
        root.addView(button("1. Разрешить доступ к статистике приложений") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        })
        root.addView(button("2. Открыть настройки частного DNS") {
            startActivity(Intent("android.settings.PRIVATE_DNS_SETTINGS"))
        })
        root.addView(button("3. Проверить разрешение Usage Access") { render() })
        root.addView(text("Статистика приложений: ${if (hasUsageAccess()) "разрешена" else "не разрешена"}", 13f, if (hasUsageAccess()) 0xFF6DE0A5.toInt() else muted))
        root.addView(text("Важно: выдача Usage Access сама по себе не даёт права менять DNS или запускать VPN. Эти механизмы будут добавлены отдельно и с явным согласием пользователя.", 12f, muted).apply { setPadding(0, 18, 0, 0) })
        setContentView(scroll)
    }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }
}
