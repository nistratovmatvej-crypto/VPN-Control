package com.vpncontrol.app

import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.VpnService
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private val bg = 0xFF080D18.toInt()
    private val panel = 0xFF121C2D.toInt()
    private val panel2 = 0xFF1A2940.toInt()
    private val white = 0xFFF4F7FF.toInt()
    private val muted = 0xFF9AAAC2.toInt()
    private val accent = 0xFF7C9BFF.toInt()
    private val prefs by lazy { getSharedPreferences("vpncontrol", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private var vpnPermissionPending = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 20)
        }
    }

    override fun onResume() { super.onResume(); if (::root.isInitialized) render() }

    private fun label(s: String, size: Float, color: Int = white, bold: Boolean = false): TextView =
        TextView(this).apply { text = s; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD); setPadding(0, 5, 0, 5) }

    private fun action(s: String, fn: () -> Unit): Button = Button(this).apply {
        text = s; isAllCaps = false; textSize = 14f; setTextColor(white)
        backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF30466F.toInt())
        setOnClickListener { fn() }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(16, 14, 16, 14)
        background = android.graphics.drawable.GradientDrawable().apply { setColor(panel); cornerRadius = 22f; setStroke(1, 0xFF253650.toInt()) }
    }

    private fun render() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 20, 18, 28); setBackgroundColor(bg) }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(root) }
        root.addView(label("VPN CONTROL", 27f, white, true))
        root.addView(label("AUTOMATION CENTER  ·  VERSION 0.2.0", 11f, muted, true))
        root.addView(label("ТВОЯ СЕТЬ. ТВОИ ПРАВИЛА.", 13f, accent, true).apply { setPadding(0, 22, 0, 10) })

        val status = card()
        val cfg = File(filesDir, "active.conf").exists()
        status.addView(label(if (cfg) "●  WireGuard-конфигурация добавлена" else "●  VPN НЕ НАСТРОЕН", 16f, if (cfg) 0xFF6DE0A5.toInt() else 0xFFFFC66D.toInt(), true))
        status.addView(label(if (cfg) "Профиль готов. Подключение будет включаться по правилам." else "Импортируй файл WireGuard .conf от своего VPN-провайдера. Без серверной конфигурации создать защищённый туннель нельзя.", 13f, muted))
        root.addView(status, margin())

        root.addView(label("БЫСТРОЕ УПРАВЛЕНИЕ", 12f, accent, true).apply { setPadding(0, 22, 0, 8) })
        val manual = card()
        manual.addView(label("WireGuard", 17f, white, true))
        manual.addView(label(if (cfg) "Профиль: ${prefs.getString("profileName", "VPN profile")}" else "Профиль не импортирован", 13f, muted))
        manual.addView(action("${if (VpnService.prepare(this) == null && prefs.getBoolean("vpnWasStarted", false)) "Переподключить" else "Подключить VPN"}") { requestVpnStart() })
        manual.addView(action("Отключить VPN") { stopVpn(); render() })
        manual.addView(action("Импортировать WireGuard .conf") { openConfigPicker() })
        root.addView(manual, margin())

        root.addView(label("АВТОМАТИЧЕСКИЕ ПРАВИЛА", 12f, accent, true).apply { setPadding(0, 22, 0, 8) })
        val rules = card()
        rules.addView(ruleRow("Telegram", "VPN включён", "org.telegram.messenger"))
        rules.addView(ruleRow("YouTube", "VPN включён", "com.google.android.youtube"))
        rules.addView(ruleRow("Claude", "Private DNS — ручная настройка Android", "com.anthropic.claude"))
        rules.addView(label("Когда Telegram и YouTube не активны — VPN отключается. Автоматизация требует постоянного мониторинга приложений.", 12f, muted))
        root.addView(rules, margin())

        root.addView(label("МОНИТОРИНГ ПРИЛОЖЕНИЙ", 12f, accent, true).apply { setPadding(0, 22, 0, 8) })
        val monitor = card()
        monitor.addView(label("Доступ к статистике: ${if (hasUsageAccess()) "РАЗРЕШЁН" else "НЕ ВЫДАН"}", 14f, if (hasUsageAccess()) 0xFF6DE0A5.toInt() else 0xFFFFC66D.toInt(), true))
        val activePackage = prefs.getString("foregroundPackage", "—") ?: "—"
        monitor.addView(label("Последнее обнаруженное приложение: $activePackage", 12f, white))
        monitor.addView(label("Android сообщает, какое приложение сейчас на переднем плане. Сервис проверяет состояние примерно раз в 2 секунды.", 12f, muted))
        monitor.addView(action("${if (hasUsageAccess()) "Перезапустить автоматику" else "Разрешить доступ к статистике"}") {
            if (!hasUsageAccess()) startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) else startMonitor()
        })
        monitor.addView(action("Остановить автоматику") { prefs.edit().putBoolean("autoEnabled", false).apply(); stopService(Intent(this, AppMonitorService::class.java)); Toast.makeText(this, "Автоматика остановлена", Toast.LENGTH_SHORT).show(); render() })
        root.addView(monitor, margin())

        root.addView(label("PRIVATE DNS", 12f, accent, true).apply { setPadding(0, 22, 0, 8) })
        val dns = card()
        val mode = Settings.Global.getString(contentResolver, "private_dns_mode") ?: "неизвестно"
        val host = Settings.Global.getString(contentResolver, "private_dns_specifier")
        dns.addView(label("Системный режим: $mode${if (!host.isNullOrBlank()) " · $host" else ""}", 14f, white, true))
        dns.addView(label("Обычное приложение Android не может автоматически переключать системный Private DNS. Это ограничение ОС. VPN-профиль WireGuard может задавать DNS внутри туннеля, но это отдельная настройка.", 12f, muted))
        dns.addView(action("Открыть настройки Private DNS") { openPrivateDnsSettings() })
        root.addView(dns, margin())

        root.addView(label("ВАЖНО", 12f, accent, true).apply { setPadding(0, 22, 0, 8) })
        root.addView(label("Для VPN нужен действующий WireGuard .conf от провайдера или собственного сервера. Android показывает системное подтверждение VPN. Переключение Private DNS стороннему приложению недоступно. Текущая версия включает/выключает весь туннель устройства, а не только трафик одного приложения.", 12f, muted))
        setContentView(scroll)
        if (hasUsageAccess() && prefs.getBoolean("autoEnabled", true)) startMonitor()
    }

    private fun ruleRow(name: String, detail: String, pkg: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL; setPadding(0, 7, 0, 7)
        val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; addView(label(name, 15f, white, true)); addView(label(detail, 11f, muted)) }
        addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        addView(label("●", 13f, accent, true))
    }

    private fun margin() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun startMonitor() {
        if (!hasUsageAccess()) { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); return }
        prefs.edit().putBoolean("autoEnabled", true).apply()
        val i = Intent(this, AppMonitorService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        Toast.makeText(this, "Автоматика запущена", Toast.LENGTH_SHORT).show()
    }

    private fun openConfigPicker() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        startActivityForResult(i, 41)
    }

    @Deprecated("Legacy picker callback for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42) {
            vpnPermissionPending = false
            if (resultCode == RESULT_OK) startWireGuard()
            else Toast.makeText(this, "Разрешение VPN не выдано", Toast.LENGTH_LONG).show()
            return
        }
        if (requestCode == 41 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input)
                    val bytes = input.readBytes()
                    val configText = bytes.toString(Charsets.UTF_8)
                    require(configText.contains("[Interface]") && configText.contains("[Peer]")) { "Это не WireGuard .conf" }
                    File(filesDir, "active.conf").writeBytes(bytes)
                    prefs.edit().putString("profileName", uri.lastPathSegment ?: "WireGuard profile").apply()
                    Toast.makeText(this, "Конфигурация сохранена", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) { Toast.makeText(this, "Ошибка импорта: ${e.message}", Toast.LENGTH_LONG).show() }
            render()
        }
    }

    private fun requestVpnStart() {
        if (!File(filesDir, "active.conf").exists()) { Toast.makeText(this, "Сначала импортируй WireGuard .conf", Toast.LENGTH_LONG).show(); return }
        val intent = VpnService.prepare(this)
        if (intent != null) { vpnPermissionPending = true; startActivityForResult(intent, 42) }
        else startWireGuard()
    }

    private fun startWireGuard() {
        try {
            val i = Intent(this, WireGuardControllerService::class.java).setAction(WireGuardControllerService.ACTION_UP)
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            prefs.edit().putBoolean("vpnWasStarted", true).apply()
            Toast.makeText(this, "Команда подключения отправлена", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Не удалось запустить VPN: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun stopVpn() {
        startService(Intent(this, WireGuardControllerService::class.java).setAction(WireGuardControllerService.ACTION_DOWN))
        prefs.edit().putBoolean("vpnWasStarted", false).apply()
    }

    private fun openPrivateDnsSettings() {
        try { startActivity(Intent("android.settings.PRIVATE_DNS_SETTINGS")) }
        catch (_: Exception) { startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
    }
}
