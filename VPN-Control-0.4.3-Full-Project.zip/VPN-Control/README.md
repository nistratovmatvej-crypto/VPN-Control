# VPN Control 0.4.3

Android VPN control app built with Kotlin and the AmneziaWG Android library.

## Build with GitHub Actions

The included workflow uses Java 17 and **Gradle 8.13**. This is required by the Android Gradle Plugin 8.12.1 configured in the root build file.

For a repository containing the project directly, commit the project files and run the `Build VPN Control APK` workflow. The debug APK is published as the `VPN-Control-0.4.3-debug` artifact.

See `BUILD-NOTES-RU.txt` for instructions matching the ZIP-extraction workflow used by the existing repository.

> The APK has not been built in this environment. A successful GitHub Actions run is still required to verify compilation and runtime behavior.
